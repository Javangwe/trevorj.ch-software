Install Uninstall Tool, and add the ProgramReg to Uninstall Tool file location and open it, if you get feature install, just
install it to run the program, if you get UAC prompt, press Yes and select Uninstall Tool Single x64 and that's it.

Thank you for downloading from Trevor's website ^_^